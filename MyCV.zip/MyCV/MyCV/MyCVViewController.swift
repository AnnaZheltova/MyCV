//
//  MyCVViewController.swift
//  MyCV
//
//  Created by Анна Желтова on 4/11/19.
//  Copyright © 2019 Анна Желтова. All rights reserved.
//

import UIKit

class MyCVViewController: UIViewController {
    
    @IBOutlet weak var photo: UIImageView!
    @IBOutlet weak var knowledge: UITextView!
    
    @IBOutlet weak var viewMore: UIView!
    @IBOutlet weak var viewKnow: UIView!
    
    
    
    
    
    override func viewDidLoad() {
        photo.layer.borderWidth = 3
        photo.layer.borderColor = UIColor.darkGray.cgColor
        viewKnow.layer.borderWidth = 1
        viewKnow.layer.cornerRadius = 30
        viewKnow.layer.shadowColor = UIColor.darkGray.cgColor
        viewKnow.layer.shadowOpacity = 0.8
        viewKnow.layer.shadowRadius = 2
        viewKnow.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        
        viewMore.layer.borderWidth = 1
        viewMore.layer.cornerRadius = 30
        viewMore.layer.shadowColor = UIColor.darkGray.cgColor
        viewMore.layer.shadowOpacity = 0.8
        viewMore.layer.shadowRadius = 2
        viewMore.layer.shadowOffset = CGSize(width: 2.0, height: 2.0)
        super.viewDidLoad()
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
