//
//  ViewController.swift
//  MyCV
//
//  Created by Анна Желтова on 4/11/19.
//  Copyright © 2019 Анна Желтова. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

